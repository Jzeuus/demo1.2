/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.groupfour.myfitnessapp;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author jesus
 */
public class UserProfileController {
   
   DBserverConnector userDB; 
   @FXML 
   private Label labelFullName; 
   @FXML 
   private Label labelEmail; 
   @FXML 
   private Label labelDoB; 
   
   
   public UserProfileController(){
   
      //DBserverConnector userDB = DBserverConnector.getInstance();
   
   }
   
   @FXML
   private void initialize(){
    userDB = DBserverConnector.getInstance();
    //setProfile();
   }
   
   public void refresh(){
   
   }
   
   @FXML
   private void setProfile(){
   ResultSet result = userDB.getResult();
   
   int id;
   String name="";
   String email="";
   String dob="";
       try {
           while (result.next()) {
               id = result.getInt("ID");
               name = result.getString("UserFullName");
               email = result.getString("Email");
               dob = result.getString("DofB");
            
               
               System.out.printf("%d %s \n", id, name);
           }
       } catch (SQLException ex) {
           Logger.getLogger(UserProfileController.class.getName()).log(Level.SEVERE, null, ex);
       }
   labelFullName.setText(name);
   labelEmail.setText(email);
   labelDoB.setText(dob);
   
   }
    
}
