/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.groupfour.myfitnessapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jesus
 * 
 * in order to get the connection to work.. need to add this dependency to pom.xml file
 * to prevent compile issues and get it to work..
 * <dependency>
 *  <groupId>com.microsoft.sqlserver</groupId>
 *  <artifactId>mssql-jdbc</artifactId>
 *   <version>7.0.0.jre8</version>
 * </dependency>
 * 
 * 
 * 
 * 
 */


public class DBserverConnector {
    
    private static DBserverConnector instance = null;
    private final String str1 = "jdbc:ucanaccess://.//ProfileData.accdb";
    private final String str2 = "jdbc:sqlserver://fitnessappserver.database.windows.net:1433;database=FitnessAppDB;user=alvaj29@fitnessappserver;password=Seniorproject1;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;";
    String connectionUrl =
                "jdbc:sqlserver://fitnessappserver.database.windows.net:1433;"
                        + "database=FitnessAppDB;"
                        + "user=alvaj29@fitnessappserver;"
                        + "password=Seniorproject1;"
                        + "encrypt=true;"
                        + "trustServerCertificate=false;"
                        + "loginTimeout=30;";
    
    Connection conn = null;
    private DBserverConnector(){
        setUpConnection();
    }
    public static DBserverConnector getInstance(){
        if(instance == null)
            instance = new DBserverConnector();
        
        return instance;
    }
    
     public static void main(String[] args) { 
         //setUpConnection();
     }
     
     private void setUpConnection(){
        System.out.println("hello world from setup connection...");
        String databaseURL = "";
        //Connection conn = null;
        try {
            databaseURL = str2 ;
            conn = DriverManager.getConnection(databaseURL);
        } catch (SQLException ex) {
            Logger.getLogger(DBserverConnector.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        if(conn == null)
            System.out.println("connection is null.. ");
        else
            System.out.println("connection is NOT null");
        
        
        //displayData(conn);
        insertRow("joe", "NY", "joey@gmail.com");
        //getData(conn);
        
        //displayData(conn);
        //saveToFile(conn);
        //clearAll(conn);
     }
     
      public void insertRow(String a, String b, String c) {
        //first check if valid inputs...

        try {
            String sql = "INSERT INTO Customers (CustomerId, Name, Location, Email) VALUES (?,?,?,?)";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, 9);
            preparedStatement.setString(2, a);
            preparedStatement.setString(3, b);
            preparedStatement.setString(4, c);
            int row = preparedStatement.executeUpdate();
            if (row > 0) {
                System.out.println("row inserted to table");
            } else {
                System.out.println("failed to add");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            //System.out.println("excepption caught..,.");
        }

    }
    
    
       private static void displayData(Connection conn) {
        
         String temp = "Customers";
         String temp2;
         
         String c1;
         String c2;
        
        try {
            String tableName = "Customers";
            Statement stmt = conn.createStatement();
            ResultSet result = stmt.executeQuery("select * from " + tableName);
            while (result.next()) {
                //int id = result.getInt("ID");
                String l = result.getString("Location");
                String n = result.getString("Name");
                //double salary = result.getFloat("Salary");

                System.out.printf("name: %s , location: %s \n", n, l);
            }
        } catch (SQLException except) {
            except.printStackTrace();
        }
    }
       
       public ResultSet getResult(){
           
            System.out.println("query data:");
            ResultSet result=null;
           try{
               String tableName="UserProfiles";
               String x = "jesus alvarado"; 
               Statement stmt = conn.createStatement();
               result = stmt.executeQuery("select * from "+ tableName 
                       + " where UserFullName=\'"+ x+ "\'");
               
               /*
               while (result.next()) 
                int id = result.getInt("ID");
                String name = result.getString("UserFullName");
                //double salary = result.getFloat("Salary");

                System.out.printf("%d %s \n", id, name);
                    */
            
                       
               
           }catch(SQLException ex){
               ex.printStackTrace();
           }
           return result;
           
       }
       
       
       private static void getData(Connection conn){
           System.out.println("query data:");
           try{
               String tableName="UserProfiles";
               String x = "jesus alvarado"; 
               Statement stmt = conn.createStatement();
               ResultSet result = stmt.executeQuery("select * from "+ tableName 
                       + " where UserFullName=\'"+ x+ "\'");
               
               
               while (result.next()) {
                int id = result.getInt("ID");
                String name = result.getString("UserFullName");
                //double salary = result.getFloat("Salary");

                System.out.printf("%d %s \n", id, name);
            }
                       
               
           }catch(SQLException ex){
               ex.printStackTrace();
           }
       
       }
     
}
