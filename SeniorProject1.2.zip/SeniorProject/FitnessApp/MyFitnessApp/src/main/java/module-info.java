module com.groupfour.myfitnessapp {
    requires java.sql;
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens com.groupfour.myfitnessapp to javafx.fxml;
    exports com.groupfour.myfitnessapp;
}
