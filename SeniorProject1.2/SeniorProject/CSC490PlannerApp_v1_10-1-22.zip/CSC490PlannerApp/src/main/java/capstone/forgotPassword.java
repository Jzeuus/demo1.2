package capstone;

/**
 * Forgot Password Class
 * 
 * Driver class for forgot password screen
 * @author Wahab Quazi
 */
public class forgotPassword {
    
}
